<?php

namespace App\Contracts;

interface AccountInterface 
{
    public function all();
    public function branchAccounts();

}