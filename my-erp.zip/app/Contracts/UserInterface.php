<?php
namespace App\Contracts;

interface UserInterface
{
    public function update($user,$request);
}