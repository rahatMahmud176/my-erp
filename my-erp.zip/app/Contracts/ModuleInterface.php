<?php
namespace App\Contracts;

interface ModuleInterface
{
    public function all();
}