
<?php $__env->startSection('title'); ?>
    Pos
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="card text-left">
            <div class="card-body">

                <div class="mt-3 clearfix">
                    <h3 class="float-start">#Point Of Sale</h3>
                    <div class="float-end">
                        <input class="my-field pos-search" placeholder="serial number" type="text">
                    </div>
                </div> 
                <div class="row"> 
                    <div class="col-md-12">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Item</th>
                                    <th scope="col">Qty</th>
                                    <th scope="col">Serial</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody class="t-body">
                                <?php echo $__env->make('backend.pos.ajax-body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </tbody>
                        </table>
                    </div> 
                </div> 
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startPush('script'); ?>
    <script>
        $('.cart-icon').on('click', function() {
            let id = $(this).attr('data-id');
            $.ajax({
                type: "GET",
                url: "<?php echo e(url('admin/add-to-cart-ajax')); ?>",
                data: {
                    id: id
                },
                success: function(res) {
                    // console.log(res);
                    toastr.success(res);
                }
            })
        })
    </script>


     
    <script>
       $('.pos-search').on('blur', function(){
        let searchKey = $(this).val();
        $.ajax({
            type: "GET",
            url : "<?php echo e(url('admin/get-pos-search-result')); ?>",
            data: {searchKey:searchKey},
            success: function(res){ 
                $('.t-body').empty();
                $('.t-body').html(res);
            }
        })
        
       })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\my-erp\resources\views/backend/pos/index.blade.php ENDPATH**/ ?>