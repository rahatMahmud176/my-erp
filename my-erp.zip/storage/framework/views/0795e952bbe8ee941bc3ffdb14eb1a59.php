
<?php $__env->startSection('title'); ?>
    Item <?php if(isset($item)): ?> Edit <?php else: ?> Add <?php endif; ?>   
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="card text-left"> 
          <div class="card-body">
             
            <div class="mt-3 clearfix">
                <h3 class="float-start">#Item <?php if(isset($item)): ?> Edit <?php else: ?> Add <?php endif; ?> </h3>
                <a href="<?php echo e(route('admin.items.index')); ?>" class="btn btn-sm btn-danger  float-end">
                     Cancel</a>
            </div>

            <div class="row">
                
                    <form class="row" action=" <?php if(isset($item)): ?> <?php echo e(route('admin.items.update',$item->id)); ?> <?php else: ?> <?php echo e(route('admin.items.store')); ?> <?php endif; ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($item)): ?>
                          <?php echo method_field('PUT'); ?>
                        <?php endif; ?>

                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                        <div class="form-group col-md-6 my-3">
                          <label for="">Item Name </label>
                          <input type="text" name="name" id="" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php if(isset($item)): ?> <?php echo e($item->name); ?> <?php endif; ?>  ">
                         </div> 

                        <div class="form-group col-md-6 my-3">   </div>

                      <div class="form-group col-md-6 my-3"> 
                        <h5 for="">  <i class="bi bi-arrow-right-short"></i>Category</h5>
                             <div class="form-check"> 
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                           
                                <label class="form-check-label">
                                    <input type="radio" class="form-check-input" name="cats[]" id="" value="<?php echo e($cat->id); ?>" <?php if(isset($item)): ?> <?php $__currentLoopData = $item->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($category->id == $cat->id ?'checked':''); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php else: ?> <?php echo e($loop->index==0?'checked':''); ?>  <?php endif; ?> >
                                    <?php echo e($cat->name); ?>

                                </label>
                                <br>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </div>
                        </div>


                      <div class="form-group col-md-6 my-3"> 
                       
                             <h5 for="">  <i class="bi bi-arrow-right-short"></i> Sub Category</h5>
                             <div class="form-check"> 

                              <?php $__currentLoopData = $subCats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                           
                              <label class="form-check-label">
                                  <input type="radio" class="form-check-input" name="sub_cats[]" id="" value="<?php echo e($cat->id); ?>" <?php if(isset($item)): ?> <?php $__currentLoopData = $item->subCats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($category->id == $cat->id ?'checked':''); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php else: ?> <?php echo e($loop->index==0?'checked':''); ?>  <?php endif; ?>>
                                  <?php echo e($cat->name); ?>

                              </label>
                              <br>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                             </div>
                        </div>

                        
                      <div class="form-group col-md-6 my-3"> 
                       
                             <h5 for="">  <i class="bi bi-arrow-right-short"></i> Country</h5>
                             <div class="form-check"> 

                              <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                               <label class="form-check-label">
                                  <input type="checkbox" class="form-check-input" name="countries[]" id="" value="<?php echo e($country->id); ?>" <?php if(isset($item)): ?> <?php $__currentLoopData = $item->countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($country->id == $coun->id ?'checked':''); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php else: ?> <?php echo e($loop->index==0?'checked':''); ?>  <?php endif; ?>>
                                  <?php echo e($country->name); ?>

                               </label>
                               <br>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                             </div>
                        </div>

                        <div class="form-group col-md-6 my-3"> 
                          
                          <h5 for="">  <i class="bi bi-arrow-right-short"></i> Brand</h5>
                          
                          


                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                           <div class="form-check">
                              <label class="form-check-label">
                                <input type="radio" class="form-check-input" name="brand" id="" value="<?php echo e($brand->id); ?>" <?php if(isset($item)): ?>  <?php echo e($item->brand->id == $brand->id ?'checked':''); ?> <?php else: ?> <?php echo e($loop->index==0?'checked':''); ?>  <?php endif; ?>>
                                <?php echo e($brand->name); ?>

                              </label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </div>

                        <div class="form-group col-md-6 my-3">  
                          <h5 for="">  <i class="bi bi-arrow-right-short"></i> Unit</h5> 
                          <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                           <div class="form-check">
                              <label class="form-check-label">
                                <input type="radio" class="form-check-input" name="unit" id="" value="<?php echo e($unit->id); ?>" <?php if(isset($item)): ?>  <?php echo e($item->unit->id == $unit->id ?'checked':''); ?> <?php else: ?> <?php echo e($loop->index==0?'checked':''); ?>  <?php endif; ?>>
                                <?php echo e($unit->name); ?>

                              </label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>


                        <div class="form-group col-md-6 my-3"> 
                          
                          <h5 for="">  <i class="bi bi-arrow-right-short"></i>Sub Unit</h5>
                           
                          <?php $__currentLoopData = $subUnits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                           <div class="form-check">
                              <label class="form-check-label">
                                <input type="radio" class="form-check-input" name="sub_unit" id="" value="<?php echo e($brand->id); ?>" <?php if(isset($item)): ?>  <?php echo e($item->subUnit->id == $brand->id ?'checked':''); ?> <?php else: ?> <?php echo e($loop->index==0?'checked':''); ?>  <?php endif; ?>>
                                <?php echo e($brand->name); ?>

                              </label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </div>

                        

                         <div class="form-group"> 
                           <button class="btn btn-secondary container-fluid mt-3"><?php if(isset($item)): ?> Update <?php else: ?> Submit  <?php endif; ?>  </button>
                         </div>

                    </form>
                 

            </div>



          </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


 
<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\my-erp\resources\views/backend/item/form.blade.php ENDPATH**/ ?>