
<?php $__currentLoopData = $supplier_transitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $transition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e(date('d-M-y', strtotime($transition->created_at))); ?></td>
        <td class="text-center"><a href="#">#Challan:<?php echo e($transition->challan_id); ?></a></td>
        <td class="text-center"><a href="#"><?php echo e($transition->supplier->name); ?></a></td>
        <td class="text-success text-center"><?php echo e($transition->deposit != 0 ?  number_format($transition->deposit, 2):'-'); ?></td>
        <td class="text-success text-center"><?php echo e($transition->due != 0 ? number_format($transition->due, 2): '-'); ?></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php /**PATH D:\projects\my-erp\resources\views/backend/transition-supplier/ajax-body.blade.php ENDPATH**/ ?>