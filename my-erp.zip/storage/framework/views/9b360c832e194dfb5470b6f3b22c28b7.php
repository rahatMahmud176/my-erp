
<?php $__env->startSection('title'); ?>
    Prducts for sale out
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="card text-left">
            <div class="card-body">



                <div class="mt-3 clearfix">
                    <h3 class="float-start">#Product for Sale out</h3>
                    <a href="<?php echo e(route('admin.pos.index')); ?>" class="btn btn-sm btn-secondary  float-end">
                        <i class="bi bi-skip-backward"></i>
                        Back to Pos</a>
                </div>

                <div class="row">
                    <div class="col-md-12">

                        <form class="row" action="<?php echo e(route('admin.cart.store')); ?>" method="post">
                            <?php echo csrf_field(); ?>

                            <div class="col-lg-12">
                                <table class="table table-bordered">
                                    <thead class="thead-light">
                                        <tr>
                                            <th scope="col" class="thead-color">Product</th>
                                            <th scope="col" class="thead-color">P.Price</th>
                                            <th scope="col" class="thead-color">S.Price</th>
                                            <th scope="col" class="thead-color">Profit (pice)</th>
                                            <th scope="col" class="thead-color">Unit Qty</th>
                                            <th scope="col" class="thead-color">Sub Unit Qty</th>
                                            <th scope="col" class="thead-color">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($content->item->name); ?></td>
                                                <input name="sale[<?php echo e($key); ?>][id]" type="hidden"
                                                    value="<?php echo e($content->id); ?>">
                                                <td>
                                                    <?php echo e(number_format($pPrice = $content->purchase_price, 2)); ?> Tk.
                                                    <input type="hidden" class="p-price<?php echo e($key); ?>"
                                                        value="<?php echo e($pPrice); ?>">
                                                </td>
                                                <td>
                                                    <input type="number" name="sale[<?php echo e($key); ?>][sale_price]"
                                                        class="form-control my-field sale-price"
                                                        data-id="<?php echo e($key); ?>" placeholder="0.00" min="1">
                                                </td>
                                                <td><span class="profit<?php echo e($key); ?>">0.00</span> Tk</td>
                                                <td>
                                                    <input name="sale[<?php echo e($key); ?>][unit_qty]" type="number"
                                                        class="form-control my-field unit_qty<?php echo e($key); ?>"
                                                        value="<?php echo e(old("sale.$key.unit_qty") ?? $content->unit_qty); ?>"
                                                        min="1"
                                                        max="<?php echo e($content->unit_qty); ?>"><?php echo e($content->item->unit->name); ?>

                                                </td>
                                                <td>
                                                    <input name="sale[<?php echo e($key); ?>][sub_unit_qty]" type="number"
                                                        class="form-control my-field"
                                                        value="<?php echo e(old("sale.$key.sub_unit_qty") ?? $content->sub_unit_qty); ?>"
                                                        max="<?php echo e($content->sub_unit_qty); ?>" min="0">
                                                    <small><?php echo e($content->item->subUnit->name); ?></small>
                                                </td>
                                                <td>
                                                    <a href="<?php echo e(route('admin.remove-cart-item', ['id' => $content->id])); ?>"
                                                        class="btn btn-danger btn-sm">Remove </a>
                                                </td>
                                            </tr>

                                            <input type="hidden" class="subtotal<?php echo e($key); ?>"
                                                placeholder="sub total">
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>

                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>

                            <div class="col-lg-6 mt-5">
                                <table class="table table-bordered">
                                    <thead class="thead-light">
                                        <tr>
                                            <th scope="col" class="thead-color">Customer Info</th>
                                            <th scope="col" class="thead-color">Inputs</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Customer Phone Number:</td>
                                            <td> <input name="phone_number" class="my-field phone_number"
                                                    placeholder="015********" value="<?php echo e(old('phone_number')); ?>"
                                                    type="text"> </td>
                                            <input type="hidden" class="customer_id" name="customer_id"
                                                value="<?php echo e(old('customer_id')); ?>" id="">
                                        </tr>
                                        <tr>
                                            <td>Customer Name:</td>
                                            <td> <input name="name" class="my-field name" placeholder="Mr. xyz"
                                                    value="<?php echo e(old('name')); ?>" type="text"> </td>
                                        </tr>
                                        <tr>
                                            <td>Customer Address:</td>
                                            <td>
                                                <textarea name="address" class="my-field address"><?php echo e(old('address')); ?></textarea>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                            <div class="col-lg-6 mt-5">
                                <table class="table table-bordered">
                                    <thead class="thead-light">
                                        <tr>
                                            <th scope="col" class="thead-color">Payment Info</th>
                                            <th scope="col" class="thead-color">Inputs</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Account Number:</td>
                                            <td>
                                                <select class="my-field" name="account_id" id="">
                                                    <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option <?php echo e($account->id == old('account_id') ? 'selected' : ''); ?>

                                                            value="<?php echo e($account->id); ?>"><?php echo e($account->ac_title); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Total Due:</td>
                                            <td> <input name="total" class="my-field due-field grandTotal" type="number"
                                                    value="<?php echo e(old('total')); ?>"> </td>
                                        </tr>
                                        <tr>
                                            <td>Payment:</td>
                                            <td> <input name="deposit" class="my-field due-field" type="number"
                                                    value="<?php echo e(old('deposit')); ?>"> </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>


                            <div class="mt-3 clearfix">
                                <button class="btn btn-success  float-end"> Submit</button>
                            </div>


                        </form>


                    </div>
                </div>



            </div>
        <?php $__env->stopSection(); ?>



        <?php $__env->startPush('script'); ?>
            <script>
                $('.sale-price').on('keyup', function() {
                    let id = $(this).attr('data-id');
                    let price = $(this).val();
                    let pPrice = $('.p-price' + id).val();
                    let profit = price - pPrice;
                    $('.profit' + id).empty();
                    $('.profit' + id).append(profit);
                })
            </script>

            <script>
                $('.sale-price').on('keyup', function() {
                    let grandTotal = 0;
                    let id = $(this).attr('data-id');
                    let price = $(this).val();
                    let qty = $('.unit_qty' + id).val();
                    let subTotal = price * qty;
                    $('.subtotal' + id).val(subTotal);

                    $('input[class^="subtotal"]').each(function() {
                        let currentSubtotal = parseFloat($(this).val()) || 0;
                        grandTotal += currentSubtotal;
                    });

                    $('.grandTotal').val(grandTotal); 
                })
            </script>


            <script>
                $('.phone_number').on('blur', function() {
                    let number = $(this).val();
                    $.ajax({
                        type: "GET",
                        url: "<?php echo e(url('admin/find-customer')); ?>",
                        data: {
                            number: number
                        },
                        success: function(res) {

                            if (res.phone_number) {
                                $('.phone_number').val(res.phone_number);
                            }
                            $('.name').val(res.name);
                            $('.address').val(res.address);
                            $('.customer_id').val(res.id);
                            console.log(res);
                        }
                    })
                })
            </script>

            <script>
                function colorDelete(id) {
                    Swal.fire({
                        title: "Are you sure?",
                        text: "You won't be able to revert this!",
                        icon: "warning",
                        showCancelButton: true,
                        confirmButtonColor: "#3085d6",
                        cancelButtonColor: "#d33",
                        confirmButtonText: "Yes, delete it!"
                    }).then((result) => {
                        if (result.isConfirmed) {
                            $('#deleteColorForm' + id).submit();
                        }
                    });
                }
            </script>
        <?php $__env->stopPush(); ?>


        <?php $__env->startPush('style'); ?>
            <style>
                .thead-color {
                    background: #6c757d !important;
                    color: white !important;
                }
            </style>
        <?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\my-erp\resources\views/backend/cart/index.blade.php ENDPATH**/ ?>