

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script> 
<script src="<?php echo e(asset('/')); ?>backend/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>  
  

<script src="<?php echo e(asset('js/iziToast.js')); ?>"></script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> 
<script src="<?php echo e(asset('/')); ?>backend/assets/js/main.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js" integrity="sha512-VEd+nq25CkR676O+pLBnDW09R7VQX9Mdiij052gVCp5yVH3jGtH70Ho/UUv4mJDsEdTvqRCFZg0NKGiojGnUCw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script> 
 <script>
     $(document).ready(function() {
        $('.select2').select2();
    });
 </script>  
<?php echo $__env->make('vendor.lara-izitoast.toast', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<?php echo $__env->yieldPushContent('script'); ?>

 <?php /**PATH D:\projects\my-erp\resources\views/backend/includes/scripts.blade.php ENDPATH**/ ?>