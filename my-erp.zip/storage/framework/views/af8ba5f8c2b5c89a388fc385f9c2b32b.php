
<?php $__env->startSection('title'); ?>
    Challan Details
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container my-5">
        <div class="card p-5">
            <div class="card-body">
                <div class="row mb-4">
                    <div class="col-6">
                        <h6 class="mb-3">Supplier:</h6>
                        <span><?php echo e($challan->supplier->name); ?></span>
                        <span><?php echo e($challan->supplier->phone_number); ?></span>
                        
                    </div>  
                </div>

                <div class="row mb-4">
                    <div class="col-sm-6">
                        <div>
                            <strong>Challan #:  <?php echo e($challan->id); ?></strong>
                        </div>
                        <div>Date: <?php echo e(date('d-M-y', strtotime($challan->created_at))); ?></div>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Description</th>
                                <th>Quantity</th>
                                <th>Purchase Price</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                        <?php $__currentLoopData = $challan->stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <tr>
                            <td><?php echo e($loop->index +1); ?></td>
                            <td><?php echo e($stock->item->name); ?> <br>
                                <small> <i class="bi bi-arrow-right"></i> <?php echo e($stock->color->name); ?> </small> <br>
                                <small> <i class="bi bi-arrow-right"></i> <?php echo e($stock->size->name); ?> </small> <br>
                                <small> <i class="bi bi-arrow-right"></i> <?php echo e($stock->country->name); ?> </small> <br> 
                                <small> <i class="bi bi-arrow-right"></i> <?php echo e($stock->serial); ?> </small> <br> 
                            </td>
                            <td><?php echo e($stock->unit_qty.' '.$stock->item->unit->name.' |'.$stock->sub_unit_qty.' '.$stock->item->subUnit->name); ?>

                            </td>
                            <td><?php echo e(number_format($stock->purchase_price)); ?></td>
                            <td><?php echo e($stock->unit_qty * $stock->purchase_price); ?></td>
                           </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            
                        </tbody>
                    </table> 

                </div> 
                <div class="row mb-4">
                    <div class="col-sm-6">
                        <div>
                            <strong>Total Amount #:  <?php echo e(number_format($challan->total)); ?></strong>
                        </div>  
                        <h6 class="mb-1 mt-3">Payment Details:</h6> 
                        <?php $__currentLoopData = $challan->transitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span> <?php echo e(date('d-M-y', strtotime($transition->created_at))); ?> : <?php echo e(number_format($transition->pay,2)); ?> tk (<?php echo e($transition->account->ac_title); ?>)</span>
                            <br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

             

                
            </div>
        </div>
    <?php $__env->stopSection(); ?>


    <?php $__env->startPush('style'); ?>
        <style>
            @media print {
                .not-print {
                    display: none;
                }

                .printable {
                    width: 100%;
                    font-size: 9px;
                    margin-top: 0 !important;
                    margin: 0;
                    /* Remove any margin to take full page width */
                    padding: 0;
                }
            }
        </style>
    <?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\my-erp\resources\views/backend/challan/challan-view.blade.php ENDPATH**/ ?>