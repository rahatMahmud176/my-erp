
<?php $__env->startSection('title'); ?>
    Items
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="card text-left">
            <div class="card-body">

                <div class="mt-3 clearfix">
                    <h3 class="float-start">#Items</h3>
                    <a href="<?php echo e(route('admin.items.create')); ?>" class="btn btn-sm btn-secondary  float-end">
                        <i class="bi bi-plus-circle"></i>
                        Add Item</a>
                </div>

                <div class="row">
                    

                    <div class="col-md-12">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Item</th>
                                    <th scope="col">Utility</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($key + 1); ?></th>
                                        <td><?php echo e($item->name.'(#'.$item->id.')'); ?> </td>
                                        <td>
                                            <table class="table table-borderless ">
                                                <tr><th>Category</th>    <td>:</td>  <td> <?php $__currentLoopData = $item->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($cat->name); ?> <?php echo e($loop->last ? '':','); ?>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td> </tr>
                                                <tr><th>SubCategory</th> <td>:</td>  <td><?php $__currentLoopData = $item->subCats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($cat->name); ?> <?php echo e($loop->last ? '':','); ?>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td> </tr>
                                                <tr><th>Brand</th>       <td>:</td>  <td><?php echo e($item->brand->name); ?></td> </tr> 
                                                <tr><th>Unit</th>        <td>:</td>  <td><?php echo e($item->unit->name); ?></td> </tr> 
                                                <tr><th>Sub Unit</th>    <td>:</td>  <td><?php echo e($item->subUnit->name); ?></td> </tr> 
                                                <tr><th>Country</th>     <td>:</td>  <td><?php $__currentLoopData = $item->countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($cat->name); ?> <?php echo e($loop->last ? '':','); ?>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td> </tr> 
                                            </table>   
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('admin.items.edit', $item)); ?>"
                                                class="btn btn-sm btn-secondary">
                                                <i class="bi bi-pencil-square"></i>
                                                Edit
                                            </a>
                                            
                                                
                                             

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </tbody>
                        </table>
                    </div>

                </div>



            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startPush('script'); ?>
    <script>
        function itemDelete(id) {
            Swal.fire({
                title: "Are you sure?",
                text: "You won't be able to revert this!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Yes, delete it!"
            }).then((result) => {
                if (result.isConfirmed) {
                    $('#deleteItemForm' + id).submit();
                }
            });
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\my-erp\resources\views/backend/item/index.blade.php ENDPATH**/ ?>