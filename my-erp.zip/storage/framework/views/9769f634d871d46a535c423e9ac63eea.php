<?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
     <td><?php echo e($stock->item->name.'('.$stock->item->id.')'); ?></td>
     <td><?php echo e($stock->color->name.','. $stock->size->name.','. $stock->country->name); ?></td>
     <td><?php echo e($stock->unit_qty.' '.$stock->item->unit->name); ?> 
        <?php if($settings->sub_unit): ?>
        <?php echo e(' / '.$stock->sub_unit_qty.' '.$stock->item->subUnit->name); ?> 
        <?php endif; ?>
     </td>
     <td><?php echo e($stock->serial); ?></td>
     <td><a href="#" class="cart-icon" data-id="<?php echo e($stock->id); ?>">
         <i class="bi bi-cart-plus-fill"></i>
         </a></td>
 </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 


<script>
    $('.cart-icon').on('click', function() {
        let id = $(this).attr('data-id');
        $.ajax({
            type: "GET",
            url: "<?php echo e(url('admin/add-to-cart-ajax')); ?>",
            data: {
                id: id
            },
            success: function(res) {
                // console.log(res);
                toastr.success(res);
            }
        })
    })
</script> 
     
<script>
    $('.pos-search').on('blur', function(){
     let searchKey = $(this).val();
     $.ajax({
         type: "GET",
         url : "<?php echo e(url('admin/get-pos-search-result')); ?>",
         data: {searchKey:searchKey},
         success: function(res){
             $('.t-body').empty();
             $('.t-body').html(res);
         }
     })
     
    })
 </script><?php /**PATH D:\projects\my-erp\resources\views/backend/pos/ajax-body.blade.php ENDPATH**/ ?>