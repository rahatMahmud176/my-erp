<tr>
    <td>
        <div class="form-group">
            <select class="form-control select2 my-field item" name="stock[<?php echo e($i); ?>][item]"  id="item" data-id="<?php echo e($i); ?>">
                <option value="">--Select--</option>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </td>

    <?php if($setting->color): ?>
        <td>
            <div class="form-group">
                <select class="form-control my-field" name="stock[<?php echo e($i); ?>][color_id]" id="">
                    <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </td>
    <?php endif; ?>

    <?php if($setting->size): ?>
        <td>
            <div class="form-group">
                <select class="form-control my-field" name="stock[<?php echo e($i); ?>][size_id]" id="">
                    <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </td>
    <?php endif; ?>
    <?php if($setting->country): ?>
        <td>
            <div class="form-group">
                <select class="form-control my-field" name="stock[<?php echo e($i); ?>][country_id]" id="">
                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </td>
    <?php endif; ?>

    <?php if($setting->qty_manage_by_serial==false ): ?>
        <td>
            <input style="width: 100px" 
                   name="stock[<?php echo e($i); ?>][unit_qty]"
                   id="unit_qty<?php echo e($i); ?>" 
                   value="<?php echo e(old("stock.$i.unit_qty")); ?>"
                   type="number" 
                   class="my-field">
        </td>
    <?php endif; ?>  

    <?php if($setting->sub_unit): ?>
        <td>
            <input style="width: 100px" name="stock[<?php echo e($i); ?>][sub_unit_qty]" id="sub_unit_qty<?php echo e($i); ?>" type="number" class="my-field">
            
        </td>
    <?php endif; ?>

    <td>
        <input style="width: 100px"  id="purchase" name="stock[<?php echo e($i); ?>][purchase]" type="number" class="my-field">
    </td>
    <?php if($setting->serial_number): ?>
    <td>
        <?php if($setting->qty_manage_by_serial): ?>
            <textarea name="stock[<?php echo e($i); ?>][serial]" id="" class="form-control my-field"></textarea>
        <?php else: ?>
            <input type="text" name="stock[<?php echo e($i); ?>][serial]" class="my-field">
        <?php endif; ?>
    </td>
    <?php endif; ?>
    <td>
        <button type="button" class="btn btn-sm btn-danger my-btn stock-row-remove">-</button>
    </td>
</tr>



 
      
<script>  //Todo
        
    $('.item').on('change', function(){
         let id = $(this).val();
         let rowId = $(this).attr('data-id'); 
          $.ajax({
                type : "GET",
                url : "<?php echo e(url('admin/get-item-info')); ?>",
                data : {id:id},
                success : function(res){ 
                     $('#unit_qty'+rowId).attr('placeholder',res.unit.name);
                     $('#sub_unit_qty'+rowId).attr('placeholder',res.sub_unit.name);
                }
          })
    })
</script>
 
<script>
    $('.stock-row-remove').on('click', function(){
        $(this).parent().parent().remove();
    })
</script>
 <?php /**PATH D:\projects\my-erp\resources\views/backend/ajax-results/stock-row.blade.php ENDPATH**/ ?>