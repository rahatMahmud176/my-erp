<header id="header" class="header fixed-top d-flex align-items-center d-print-none">

    <div class="d-flex align-items-center justify-content-between">
      <a href="<?php echo e(asset('/')); ?>" class="logo d-flex align-items-center">
        <img src="<?php echo e(asset('/')); ?>backend/assets/img/logo.png" alt="">
        <span class="d-none d-lg-block">My-ERP</span>
      </a>
      <i class="bi bi-list toggle-sidebar-btn"></i>
    </div><!-- End Logo -->

    

    <nav class="header-nav ms-auto">
      <ul class="d-flex align-items-center">

        <li class="nav-item d-block d-lg-none">
          <a class="nav-link nav-icon search-bar-toggle " href="#">
            <i class="bi bi-search"></i>
          </a>
        </li><!-- End Search Icon-->

        

          

          

            

            

          

        

        <li class="nav-item dropdown">

          <a class="nav-link nav-icon" href="<?php echo e(route('admin.cart.index')); ?>"> 
            <i class="bi bi-basket"></i>
            
          </a><!-- End Messages Icon -->
 

        </li><!-- End Messages Nav -->

        <li class="nav-item dropdown pe-3">

          <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
            
            <span class="d-none d-md-block dropdown-toggle ps-2"><?php echo e(auth()->user()->name); ?></span>
          </a><!-- End Profile Iamge Icon -->

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
            <li class="dropdown-header">
              <h6><?php echo e(auth()->user()->name); ?></h6>
              <span><?php echo e(auth()->user()->role->name); ?></span>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="<?php echo e(route('profile.edit')); ?>">
                <i class="bi bi-person"></i>
                <span>My Profile</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>
  

            <li>
              <a class="dropdown-item d-flex align-items-center" href="#"
                onclick="event.preventDefault(); $('#logoutForm').submit()"
              >
                <i class="bi bi-box-arrow-right"></i>
                <span>Log Out</span>
              </a>
            </li>

            <form id="logoutForm" action="<?php echo e(route('logout')); ?>" method="post"><?php echo csrf_field(); ?></form>

          </ul><!-- End Profile Dropdown Items -->
        </li><!-- End Profile Nav -->

      </ul>
    </nav><!-- End Icons Navigation -->

  </header><!-- End Header --><?php /**PATH D:\projects\my-erp\resources\views/backend/includes/header.blade.php ENDPATH**/ ?>