



<?php $__env->startSection('title'); ?>
    Stock <?php if(isset($stock)): ?>
        Edit
    <?php else: ?>
        Add
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="mt-4"></div>

    <div class="row">
        <div class="card text-left">
            <div class="card-body">
                <div class="mt-3 clearfix">
                    <h3 class="float-start">#Stock <?php if(isset($stock)): ?>
                            Edit
                        <?php else: ?>
                            Add
                        <?php endif; ?> </h3>
                    <a href="<?php echo e(route('admin.stocks.index')); ?>" class="btn btn-sm btn-danger  float-end">
                        Cancel</a>
                </div>

                <div class="row">


                    <form
                        action=" <?php if(isset($stock)): ?> <?php echo e(route('admin.stocks.update', $stock->id)); ?> <?php else: ?> <?php echo e(route('admin.stocks.store')); ?> <?php endif; ?>"
                        method="post">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($stock)): ?>
                            <?php echo method_field('PUT'); ?>
                        <?php endif; ?>

                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>



                        <div class="row">
                            <div class="form-group col-md-3 my-3">
                                <div class="form-group">
                                    <label for="">Supplier 
                                        <button type="button" 
                                                class="btn btn-sm my-btn  btn-secondary"
                                                data-bs-toggle="modal" data-bs-target="#supplierModal">+</button></label>
                                    <select class="form-control select2 my-field" name="supplier_id" id="">
                                        <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group col-md-6 my-3"> </div>

                            <div class="form-group col-md-3 my-3">
                                <div class="form-group">
                                    <label for="">Challan / Lot Traking </label>
                                    <input type="text" readonly name="challan" class="form-control my-field"
                                        value="<?php echo e($challanId); ?>">
                                </div>
                            </div>
                        </div>



                        <table class="table table-striped mt-3 stock-table">
                            <tr>
                                <th>item</th>
                                <?php if($setting->color): ?>
                                    <th>color 
                                        <button type="button" 
                                        class="btn btn-sm my-btn btn-secondary"
                                        data-bs-toggle="modal" data-bs-target="#colorModal">+</button></th>
                                <?php endif; ?>
                                <?php if($setting->size): ?>
                                    <th>size <button type="button" class="btn btn-sm my-btn btn-secondary"
                                        data-bs-toggle="modal"
                                        data-bs-target="#sizeModal">+</button></th>
                                <?php endif; ?>
                                <?php if($setting->country): ?>
                                    <th>country <button type="button" 
                                                        class="btn btn-sm my-btn btn-secondary"
                                                        data-bs-toggle="modal"
                                                        data-bs-target="#countryModal">+</button></th>
                                <?php endif; ?>

                                <?php if($setting->qty_manage_by_serial == false): ?>
                                    <th>Qty (unit) <button type="button" class="btn btn-sm my-btn  btn-secondary">+</button></th>
                                <?php endif; ?>


                                <?php if($setting->sub_unit): ?>
                                    <th>Qty (sub-unit) <button type="button" class="btn btn-sm my-btn  btn-secondary">+</button></th>
                                <?php endif; ?>
                                <th>Purchase p.</th>
                                <?php if($setting->serial_number): ?>
                                    <th>SL / IMEI No.</th>
                                <?php endif; ?>
                                <th>Action</th>
                            </tr>

                            <tr>
                                <td>
                                    <div class="form-group">
                                        <select class="form-control select2 my-field" name="stock[1][item]" id="item">
                                            <option value="">--Select--</option>
                                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?> <small class="text-black-50"><?php echo e('(ID:'.$item->id.')'); ?></small></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </td>

                                <?php if($setting->color): ?>
                                    <td>
                                        <div class="form-group">
                                            <select class="form-control select2 my-field" name="stock[1][color_id]" id="">
                                                <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </td>
                                <?php endif; ?>

                                <?php if($setting->size): ?>
                                    <td>
                                        <div class="form-group">
                                            <select class="form-control select2 my-field" name="stock[1][size_id]" id="">
                                                <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </td>
                                <?php endif; ?>
                                <?php if($setting->country): ?>
                                    <td>
                                        <div class="form-group">
                                            <select class="form-control select2 my-field" name="stock[1][country_id]"
                                                id="">
                                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </td>
                                <?php endif; ?>

                                <?php if($setting->qty_manage_by_serial == false): ?>
                                    <td>
                                        <input style="width: 100px" name="stock[1][unit_qty]" id="unit_qty" type="number"
                                            value="<?php echo e(old('stock.1.unit_qty')); ?>" class="my-field">
                                    </td>
                                <?php endif; ?>

                                <?php if($setting->sub_unit): ?>
                                    <td>
                                        <input style="width: 100px" 
                                               name="stock[1][sub_unit_qty]" 
                                               value="<?php echo e(old("stock.1.sub_unit_qty")); ?>"
                                               id="sub_unit_qty"
                                               type="number" 
                                               class="my-field">

                                    </td>
                                <?php endif; ?>

                                <td>
                                    <input style="width: 100px" 
                                            id="purchase" 
                                            name="stock[1][purchase]" type="number"
                                            value="<?php echo e(old("stock.1.purchase")); ?>"
                                            class="my-field">
                                </td>
                                <?php if($setting->serial_number): ?>
                                    <td>
                                        <?php if($setting->qty_manage_by_serial): ?>
                                            <textarea name="stock[1][serial]"
                                                      value="<?php echo e(old("stock.1.serial")); ?>"
                                                      id="" 
                                                      class="form-control my-field"></textarea>
                                        <?php else: ?>
                                            <input type="text" 
                                                   name="stock[1][serial]" 
                                                   value="<?php echo e(old("stock.1.serial")); ?>"
                                                   class="my-field">
                                        <?php endif; ?>
                                    </td>
                                <?php endif; ?>
                                <td>
                                    <button type="button" class="btn btn-sm btn-success my-btn add-row">+</button>
                                </td>
                            </tr>

                        </table>




                        <div class="row">
                            <div class="form-group col-md-3 my-3">
                                <div class="form-group">
                                    <label for="">Payment Type <button type="button" class="btn btn-sm my-btn  btn-secondary">+</button></label>
                                    <select class="form-control select2 my-field" name="account_id" id="accounts">
                                        <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e(old('account_id') == $item->id ? 'selected':''); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->ac_title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group col-md-6 my-3"> </div>

                            <div class="form-group col-md-3 my-3">
                                <table class="table table-bordered">
                                    <tr>
                                        <th>Total =</th>
                                        <td> <input name="total" 
                                                    value="<?php echo e(old('total')); ?>"
                                                    class="form-control my-field" 
                                                    type="number"
                                                    id="total"></td>
                                    </tr>
                                    <tr>
                                        <th>Pay =</th>
                                        <td><input name="pay"
                                                   value="<?php echo e(old('pay')); ?>"
                                                   type="number" 
                                                   id="pay"
                                                   class="form-control my-field"></td>
                                    </tr>
                                    <tr>
                                        <th>Due =</th>

                                        <td><input name="due" 
                                                   value="<?php echo e(old('due')); ?>"
                                                   type="number" 
                                                   id="due" 
                                                   readonly
                                                class="form-control my-field"></td>
                                    </tr>
                                </table>
                            </div>
                        </div>


                        <div class="form-group col-1 float-end">
                            <button class="btn btn-secondary container-fluid mt-3">
                                <?php if(isset($stock)): ?>
                                    Update
                                <?php else: ?>
                                    Submit
                                <?php endif; ?>
                            </button>
                        </div> 
                    </form> 

                </div>  
            </div>
        </div>
    </div>













<?php $__env->stopSection(); ?>





<?php $__env->startPush('modal'); ?>


 
<form action="<?php echo e(route('admin.country_variants.store')); ?>" method="post">
    <?php echo csrf_field(); ?>  
  <div class="modal fade" id="countryModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="exampleModalLabel">Country Register Form</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <div class="form-group">
              <label for="">Country Name</label>
              <input type="text" name="name" id="" class="form-control" placeholder="" aria-describedby="helpId">
             </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Save </button>
        </div>
      </div>
    </div>
  </div> 
</form>

 
<form action="<?php echo e(route('admin.sizes.store')); ?>" method="post">
    <?php echo csrf_field(); ?>  
  <div class="modal fade" id="sizeModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="exampleModalLabel">Size Register Form</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <div class="form-group">
              <label for="">Size Name</label>
              <input type="text" name="name" id="" class="form-control" placeholder="" aria-describedby="helpId">
             </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Save </button>
        </div>
      </div>
    </div>
  </div> 
</form>
 
<form action="<?php echo e(route('admin.colors.store')); ?>" method="post">
    <?php echo csrf_field(); ?>  
  <div class="modal fade" id="colorModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="exampleModalLabel">Color Register Form</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <div class="form-group">
              <label for="">Color Name</label>
              <input type="text" name="name" id="" class="form-control" placeholder="" aria-describedby="helpId">
             </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Save </button>
        </div>
      </div>
    </div>
  </div> 
</form>









<form action="<?php echo e(route('admin.suppliers.store')); ?>" method="post">
    <?php echo csrf_field(); ?> 
    <div class="modal fade" id="supplierModal" tabindex="-1" aria-labelledby="supplierModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h1 class="modal-title fs-5" id="supplierModalLabel">Supplier Register Form</h1>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body row"> 
                
                <div class="form-group">
                  <label for="">Supplier Name</label>
                  <input type="text" 
                         name="name" 
                         id="" required
                         class="form-control" 
                         placeholder="" 
                         aria-describedby="helpId">
                </div>
                <div class="form-group mb-3">
                  <label for="">Supplier Phone Number </label>
                  <input type="text" name="phone_number" id="" class="form-control" placeholder="" aria-describedby="helpId">
                </div>

            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary"> Save </button>
            </div>
          </div>
        </div>
      </div> 
</form>  
 

     
 
<?php $__env->stopPush(); ?>

 









<?php $__env->startPush('script'); ?>
    <script>
        $('#item').on('change', function() {
            let id = $(this).val();
            $.ajax({
                type: "GET",
                url: "<?php echo e(url('admin/get-item-info')); ?>",
                data: {
                    id: id
                },
                success: function(res) {
                    console.log(res);
                    $('#unit_qty').attr('placeholder', res.unit.name);
                    $('#sub_unit_qty').attr('placeholder', res.sub_unit.name);
                }
            })
        })
    </script>

    <script>
        $('#unit_qty, #purchase').on('keyup', function() {
            var qty = $('#unit_qty').val();
            var price = $('#purchase').val();
            var total = qty * price;
            $('#total').empty();
            $('#total').val(total);
        })
    </script>

    <script>
        $('#pay,#unit_qty, #purchase').on('keyup', function() {
            let pay = $('#pay').val();
            let total = $('#total').val();
            $('#due').empty();
            $('#due').val(total - pay);
        })
    </script>

    <script>
        $('#pay').on('click', function() {
            $.ajax({
                type: "GET",
                url: "<?php echo e(url('admin/get-account-info-without-first-one')); ?>",
                success: function(res) {
                    console.log(res);
                    $('#accounts').empty();
                    $('#accounts').html(res);
                }
            })
        })
    </script>


    <script>
        var i = 2;
        $('.add-row').on('click', function() { 
            $.ajax({
                type: "GET",
                data: {
                    i: i
                },
                url: "<?php echo e(url('admin/add-stock-row')); ?>",
                success: function(res) { 
                    $('.stock-table').append(res);
                    i++;
                }
            })
        })
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('style'); ?>
    <style>
        .my-btn {
            --bs-btn-padding-y: 0px;
            --bs-btn-padding-x: 5px;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master-without-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\my-erp\resources\views/backend/stock/form.blade.php ENDPATH**/ ?>