<?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><?php echo e(date('d-M-y', strtotime($stock->created_at))); ?> </td>
    <td><?php echo e($stock->item->name); ?> </td>
    <td><?php echo e($stock->serial); ?> </td>
    <td><?php echo e($stock->supplier->name); ?> </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\projects\my-erp\resources\views/backend/product-history/ajax-body.blade.php ENDPATH**/ ?>