<?php
    $totalUnitQty = 0;
    $unitName = '';
    $i = 1;
?>
<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($item->stocks->sum('unit_qty') != 0): ?>
        <tr>
            <th scope="row"><?php echo e($i++); ?></th>
            <td><?php echo e($item->name); ?> <small class="text-black-50"><?php echo e('(ID:'.$item->id.')'); ?></small></td>

            <td>
                <?php echo e($item->stocks->sum('unit_qty')); ?>

                <input type="hidden" name=""
                    value="<?php echo e($totalUnitQty = $totalUnitQty + $item->stocks->sum('unit_qty')); ?>">
                <?php if($item->unit_id != 1): ?>
                    <?php echo e($unitName = $item->unit->name); ?>

                <?php endif; ?>
                <?php if($item->sub_unit_id != 1): ?>
                    <?php echo e(' / ' . $item->stocks->sum('sub_unit_qty') . ' ' . $item->subUnit->name); ?>

                <?php endif; ?>
            </td>


            <td>
                <a href="<?php echo e(route('admin.stock.details', ['id' => $item->id])); ?>" class="btn btn-sm btn-secondary">
                    <i class="bi bi-pencil-eye"></i>
                    view
                </a>
            </td>
        </tr>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td></td>
    <th> Total =</th>
    <td> <?php echo e($totalUnitQty . ' ' . $unitName); ?> </td>
    <td></td>
</tr>
 <?php /**PATH D:\projects\my-erp\resources\views/backend/stock/ajax-body.blade.php ENDPATH**/ ?>