<?php
    $totalSale = 0;
    $totalProfit = 0;
?>

<?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e(date('d-M-y', strtotime($invoice->created_at))); ?></td>
        <td scope="row">Invoice#<?php echo e($invoice->id); ?></td>
        <td scope="row">
            <?php echo e($invoice->customer->name); ?> <br>
            <small><?php echo e($invoice->customer->phone_number); ?></small>
        </td>
        <td scope="row"><?php echo e($invoice->branch->name); ?></td>
        <td scope="row"><?php echo e(number_format($total = $invoice->total, 2)); ?></td>
        <td scope="row"><?php echo e(number_format($due = $total - $invoice->transitions->sum('deposit'), 2)); ?></td>
        <td scope="row">
            <?php
                $totalPurchasePrice = 0; 
            ?>
            <?php $__currentLoopData = $invoice->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="hidden" name="" value="<?php echo e($totalPurchasePrice = $totalPurchasePrice + $detail->stock->purchase_price); ?>">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php echo e(number_format($invoice->total - $totalPurchasePrice, 2)); ?> 
            <input type="hidden" name="" value="<?php echo e($totalProfit = $totalProfit+ $invoice->total - $totalPurchasePrice); ?>">
            <input type="hidden" name="" value="<?php echo e($totalSale = $totalSale+ $total); ?>">
            
        </td>
        <td scope="row">

            <?php if($invoice->deletable == true): ?>
                <?php if($due != 0): ?>
                    <a href="#" data-id = "<?php echo e($invoice->id); ?>" data-due = "<?php echo e($due); ?>"
                        class="btn btn-sm btn-success pay-invoice" data-bs-toggle="modal"
                        data-bs-target="#exampleModal">
                        <i class="bi bi-coin"></i>
                        Pay</a>
                <?php endif; ?>


                <a href="<?php echo e(route('admin.invoice.show', $invoice->id)); ?>" class="btn btn-sm btn-secondary">View</a>
                <a href="#" onclick="invoiceDelete(<?php echo e($invoice->id); ?>)" class="btn btn-sm btn-danger">
                    <i class="bi bi-trash3-fill"></i>
                    Delete</a>

                <form id="deleteInvoiceForm<?php echo e($invoice->id); ?>"
                    action="<?php echo e(route('admin.invoice.destroy', $invoice)); ?>" method="post">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>
                </form>
            <?php endif; ?>

        </td>

    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td></td>
    <th>Total =</th>
    <td></td>
    <td></td>
    <th>Sale: <?php echo e(number_format($totalSale)); ?></th>
    <td></td>
    <th> Profit: <?php echo e(number_format($totalProfit)); ?></th>
    <td></td>
</tr>




<script>
    $('.pay-invoice').on('click', function() {
        let id = $(this).attr('data-id');
        let deu = $(this).attr('data-due');
        $('#pay-amount').attr('max', deu);
        const nFormat = new Intl.NumberFormat(undefined, {
            minimumFractionDigits: 2
        });
        $('#invoice_id').val(id);
        $('#due').val(nFormat.format(deu));
        $('#exampleModalLabel').empty();
        $('#exampleModalLabel').append('Invoice#' + id);
    })
</script>

<script>
    function invoiceDelete(id) {
        Swal.fire({
            title: "Are you sure?",
            text: "You won't be able to revert this!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonInvoice: "#3085d6",
            cancelButtonInvoice: "#d33",
            confirmButtonText: "Yes, delete it!"
        }).then((result) => {
            if (result.isConfirmed) {
                $('#deleteInvoiceForm' + id).submit();
            }
        });
    }
</script>
<?php /**PATH D:\projects\my-erp\resources\views/backend/invoice/ajax-invoice-body.blade.php ENDPATH**/ ?>