
<?php $__env->startSection('title'); ?>
    Stocks
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="card text-left">
            <div class="card-body">

                 

                <div class="mt-3 clearfix">
                    <h3 class="float-start">#Stocks</h3>

                    <select class="float-end category" name="" id="">
                        <option value=""> Categories </option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"> <?php echo e($category->name); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                 
                </div>

                <div class="row"> 
                    <div class="col">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Item </th> 
                                    <th scope="col">Qty</th>  
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody class="stock-body">

                                <?php echo $__env->make('backend.stock.ajax-body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                            </tbody>
                        </table>
                    </div>

                </div>



            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startPush('script'); ?>
    <script>
        function stockDelete(id) {
            Swal.fire({
                title: "Are you sure?",
                text: "You won't be able to revert this!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonStock: "#3085d6",
                cancelButtonStock: "#d33",
                confirmButtonText: "Yes, delete it!"
            }).then((result) => {
                if (result.isConfirmed) {
                    $('#deleteStockForm' + id).submit();
                }
            });
        }
    </script>

    <script>
        $('.category').on('change', function(){
            let id = $(this).val();
            $.ajax({
                type: "GET",
                url : "<?php echo e(url('admin/get-stock-by-category')); ?>",
                data: {id:id},
                success: function(res){ 
                    $('.stock-body').empty();
                    $('.stock-body').html(res); 
                }

            })
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\my-erp\resources\views/backend/stock/index.blade.php ENDPATH**/ ?>