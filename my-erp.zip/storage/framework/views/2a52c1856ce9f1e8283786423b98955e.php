
<?php $__env->startSection('title'); ?>
    SubCategory Edit  
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="card text-left"> 
          <div class="card-body">
             
            <div class="mt-3 clearfix">
                <h3 class="float-start">#SubCategory Edit</h3>
                <a href="<?php echo e(route('admin.sub-categories.index')); ?>" class="btn btn-sm btn-danger float-end">
                     Cancel</a>
            </div>

            <div class="row">
                <div class="col-md-6 mx-auto">
                    <form action="<?php echo e(route('admin.sub-categories.update',$subCategory->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?> 

                        <div class="form-group">
                          <label for="" class="mb-2">Category</label>
                          <select class="form-control" name="cat" id="">
                              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e($category->id ==  $subCategory->category->id ?'selected':''); ?>  value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                          </select>
                      </div>

                        <div class="form-group mt-3">
                          <label for="">Sub Category</label>
                          <input type="text" name="name" id="" class="form-control" value="<?php echo e($subCategory->name); ?>">
                         </div>

                         <div class="form-group"> 
                           <button class="btn btn-secondary container-fluid mt-3">Update </button>
                         </div>

                    </form>
                </div> 

            </div>



          </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


 
<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\my-erp\resources\views/backend/sub-category/form.blade.php ENDPATH**/ ?>