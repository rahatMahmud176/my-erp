<?php
    $totalPay = 0;
    $totalDeposit = 0;
?>

<?php $__currentLoopData = $transitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $transition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><?php echo e(date("d-M-y" , strtotime($transition->created_at))); ?></td> 
    <td class="text-center"><a href="#"><?php echo e($transition->account->ac_title); ?></a></td>

    <td class="text-center">
        <?php if($transition->challan_id != 1): ?>
            <a href="#">#Challan:<?php echo e($transition->challan_id); ?></a> <br>
        <?php else: ?>
            <a href="#">#Invoice:<?php echo e($transition->invoice_id); ?></a>
        <?php endif; ?> 
        
    </td> 

    <td class="text-center">
        <?php if($transition->challan_id != 1): ?>
            #Supp: <a href="#"><?php echo e($transition->challan->supplier->name); ?></a> <br>
        <?php else: ?>
           #Cust: <a href="#"><?php echo e($transition->invoice->customer->name); ?></a>
        <?php endif; ?>  
    </td> 
         <td class="text-success text-center"><?php echo e($transition->deposit != 0 ? number_format($transition->deposit,2): '-'); ?></td>
        <td class="text-success text-center"><?php echo e($transition->pay != 0 ? number_format($transition->pay,2): '-'); ?></td> 
   </tr>

   <input type="hidden" name="" value="<?php echo e($totalPay = $totalPay + $transition->pay); ?>">
   <input type="hidden" name="" value="<?php echo e($totalDeposit = $totalDeposit + $transition->deposit); ?>">


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<tr> 
    <td></td>
    <td></td>
    <td></td>
    <th class="text-center">Total =</th>
    <th class="text-center"><?php echo e(number_format($totalDeposit)); ?></th>
    <th class="text-center"><?php echo e(number_format($totalPay)); ?></th>
</tr><?php /**PATH D:\projects\my-erp\resources\views/backend/transition/body-ajax.blade.php ENDPATH**/ ?>