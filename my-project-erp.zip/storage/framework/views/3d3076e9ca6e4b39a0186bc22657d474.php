
<?php $__env->startSection('title'); ?>
    invoice
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?> 

<div class="container my-5">
    <div class="card p-5">
        <div class="card-body">
            <div class="row mb-4">
                <div class="col-6">
                    <h6 class="mb-3">From:</h6>
                    <div>
                        <strong><?php echo e($company->company_name); ?></strong>
                    </div>
                    <div><?php echo e($company->company_address); ?></div>  
                    <div>Phone: <?php echo e($company->company_phone_number); ?></div>
                </div>

                <div class="col-6 text-sm-end">
                    <h6 class="mb-3">To:</h6>
                    <div>
                        <strong><?php echo e($invoice->customer->name); ?></strong>
                    </div> 
                    <div><?php echo e($invoice->customer->address); ?></div>
                    <div>Email: <?php echo e($invoice->customer->email); ?></div>
                    <div>Phone: <?php echo e($invoice->customer->phone_number); ?></div>
                </div>
            </div>

            <div class="row mb-4">
                <div class="col-sm-6"> 
                    <div>
                        <strong>Invoice #: <?php echo e($invoice->id); ?></strong>
                    </div>
                    <div>Date: <?php echo e(date('d-M-y', strtotime($invoice->created_at))); ?></div> 
                </div>
            </div>

            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Description</th>
                            <th>Quantity</th>
                            <th>Unit Price</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php
                            $total = 0; 
                        ?>

                    <?php $__currentLoopData = $invoice->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <tr>
                            <td><?php echo e($key++); ?></td>
                            <td>
                                <?php echo e($details->stock->item->name); ?> <br>
                                <small> <i class="bi bi-arrow-right"></i> <?php echo e($details->stock->color->name); ?> </small> <br>
                                <small> <i class="bi bi-arrow-right"></i> <?php echo e($details->stock->size->name); ?> </small> <br>
                                <small> <i class="bi bi-arrow-right"></i> <?php echo e($details->stock->country->name); ?> </small> <br>
                            </td>
                            <td>
                                <?php echo e($details->unit_qty.' ('.$details->stock->item->unit->name.')'); ?> <br>
                                <?php echo e($details->sub_unit_qty.' ('.$details->stock->item->subUnit->name.')'); ?>

                            </td>
                            <td><?php echo e(number_format($details->sale_price, 2)); ?></td>
                            <input type="hidden" value="<?php echo e($subTotal =  $details->sale_price * $details->unit_qty); ?>">
                            <td><?php echo e(number_format($subTotal, 2)); ?></td>
                        </tr>

                        <input type="hidden" value="<?php echo e($total= $total+$subTotal); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                        <tr>
                            <td colspan="4" class="text-end"><strong>Subtotal</strong></td>
                            <td><?php echo e(number_format($total,2)); ?></td>
                        </tr>
                        
                    </tbody>
                </table>
            </div>


            <div class="row mb-4">
                <div class="col-sm-6">
                    <h6 class="mb-3">Payment Details:</h6> 
                    <?php $__currentLoopData = $invoice->transitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span> <?php echo e(date('d-M-y', strtotime($transition->created_at))); ?> : <?php echo e(number_format($transition->deposit,2)); ?> tk</span>
                        <br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>


            <div class="text-center mt-3">
                <p class="text-muted">Thank you for your purchase!</p>
            </div>
        </div>

        <a href="javascript:window.print()" class="btn btn-secondary d-print-none float-end">Print</a>
    </div>  
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('style'); ?>
    <style>
        @media print {
        .not-print{
            display: none;
        }
        .printable{
            width: 100%;
            font-size: 9px;
            margin-top:0 !important;
            margin: 0; /* Remove any margin to take full page width */
            padding: 0;
        }
    }
    </style>
<?php $__env->stopPush(); ?>
 




<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\my-erp\resources\views/backend/invoice/invoice.blade.php ENDPATH**/ ?>