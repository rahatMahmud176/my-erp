<footer id="footer" class="footer d-print-none">
    <div class="copyright">
      &copy; Copyright <strong><span>Rahat Mahmud</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
      Designed by <a href="#">Rahat mahmud</a>
    </div>
  </footer><!-- End Footer -->