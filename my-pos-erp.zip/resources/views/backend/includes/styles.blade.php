
  <!-- Favicons -->
  <link href="={{ asset('/') }}backend/assets/img/favicon.png" rel="icon">
  <link href="{{ asset('/') }}backend/assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="{{ asset('/') }}backend/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="{{ asset('/') }}backend/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet"> 

{{-- izetoast  --}}
<link href="{{ asset('css/iziToast.css') }}" rel="stylesheet">

{{-- toster   --}}
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css" integrity="sha512-3pIirOrwegjM6erE5gPSwkUzO+3cTjpnV9lexlNZqvupR64iZBnOOTiiLPb9M36zpMScbmUNIcHUqKD47M719g==" crossorigin="anonymous" referrerpolicy="no-referrer" />

{{-- select 2 --}}
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
 

  <!-- Template Main CSS File -->
  <link href="{{ asset('/') }}backend/assets/css/style.css" rel="stylesheet"> 

  @stack('style')

 